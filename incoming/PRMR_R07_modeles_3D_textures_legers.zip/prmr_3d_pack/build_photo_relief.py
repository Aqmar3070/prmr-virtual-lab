"""Generate compact 3D embossed photo-sculptures from single-view PRMR cutout renders.
Explicit limitation: 2.5D shape reconstruction, backside mirrored, non-anatomically validated.
Uses embedded WEBP via glTF EXT_texture_webp; only standalone local imagery.
"""
from pathlib import Path
from PIL import Image, ImageFilter
import numpy as np, cv2, struct, json, hashlib, os, time
P=Path('/mnt/data');OUT=P/'prmr_3d_pack'/'assets'
FILES={
'mouse':'souris_albinos_de_laboratoire_détourée.png',
'rat':'rat_de_laboratoire_albinos_réaliste.png',
'pig':'miniporc_biomédical_rose_pâle_en_pied.png',
'dog':'beagle_tricolore_en_pose_alerte.png',
'nhp':'macaque_brun_en_pose_quadrupède.png',
'rabbit':'lapin_albinos_réaliste_détouré.png'}

# glTF interleaved attributes use standard 4-byte component alignment
align=lambda n,a:(n+(a-1))&~(a-1)
def build(id,filename):
    img=Image.open(P/filename).convert('RGBA')
    # Crop some of the irrelevant transparent border preserving the animal's whole anatomy.
    alpha=img.getchannel('A')
    bbox=alpha.point(lambda x:255 if x>55 else 0).getbbox()
    x0,y0,x1,y1=bbox
    xpad=max(20,int((x1-x0)*.045));ypad=max(20,int((y1-y0)*.045))
    x0=max(0,x0-xpad);y0=max(0,y0-ypad);x1=min(img.width,x1+xpad);y1=min(img.height,y1+ypad)
    img=img.crop((x0,y0,x1,y1))
    # Uniform aspect ratio for all species, preserving silhouette and whiskers.
    canvas=Image.new('RGBA',(512,384),(0,0,0,0))
    img.thumbnail((506,374),Image.Resampling.LANCZOS)
    canvas.alpha_composite(img,((512-img.width)//2,(384-img.height)//2))
    # Tame colored edge halos by drawing only pixels with enough alpha.
    a=np.array(canvas.getchannel('A'))
    a=cv2.GaussianBlur(a,(3,3),.55)
    a=np.where(a<42,0,np.where(a>250,255,a)).astype('uint8')
    canvas.putalpha(Image.fromarray(a))
    webp=OUT/'animals-photo'/f'{id}.webp';canvas.save(webp,'WEBP',quality=64,method=4,exact=False)
    texture=webp.read_bytes()
    # build depth 3D from entire silhouette. 84 x 63 grid -> low-memory mesh.
    nx,ny=110,82
    mask=cv2.resize(a.astype('float32'),(nx,ny),interpolation=cv2.INTER_AREA)
    visible=mask>85
    # Preserve tiny details except unsupported detached bits; close 1-2px gaps on grid.
    visible=cv2.morphologyEx(visible.astype('uint8'),cv2.MORPH_CLOSE,np.ones((2,2),np.uint8))>0
    depth=cv2.distanceTransform(visible.astype('uint8'),cv2.DIST_L2,5)
    # For thin limbs/tail, small 3D depth. Broad torso gets more volume.
    depth_val=.032+.54*np.tanh(depth/12)
    dy,dx=np.gradient(depth_val)
    width=4.2;height=3.15;stepx=width/(nx-1);stepy=height/(ny-1)
    verts=[];normals=[];uv=[];front={};back={}
    def add(x,y,z,n,u,v):
        k=len(verts);verts.append((x,y,z));normals.append(tuple(n));uv.append((u,v));return k
    for j in range(ny):
        for i in range(nx):
            if not visible[j,i]:continue
            x=(i/(nx-1)-.5)*width;y=(.5-j/(ny-1))*height
            z=float(depth_val[j,i]);nz=np.array([-float(dx[j,i])/stepx,float(dy[j,i])/stepy,1.],np.float32)
            nz/=max(1e-10,np.linalg.norm(nz))
            front[i,j]=add(x,y,z,nz,i/(nx-1),1-j/(ny-1))
            back[i,j]=add(x,y,-z,(-nz[0],-nz[1],-nz[2]),1-i/(nx-1),1-j/(ny-1))
    faces=[]
    for j in range(ny-1):
        for i in range(nx-1):
            q=((i,j),(i+1,j),(i,j+1),(i+1,j+1))
            if all(k in front for k in q):
                # Front faces CCW seen from +Z, back opposite winding
                faces.extend([front[q[0]],front[q[2]],front[q[1]], front[q[2]],front[q[3]],front[q[1]]])
                faces.extend([back[q[0]],back[q[1]],back[q[2]], back[q[2]],back[q[1]],back[q[3]]])
    # Sidewalls: connect boundary edges to form a water-tight shaded shell.
    contour_mask=(visible*255).astype('uint8')
    contours,_=cv2.findContours(contour_mask,cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)
    side_count=0
    for c in contours:
        if len(c)<5:continue
        points=c[:,0,:].tolist()
        for k in range(len(points)):
            ia,ja=points[k];ib,jb=points[(k+1)%len(points)]
            aa=(ia,ja);bb=(ib,jb)
            if aa not in front or bb not in front:continue
            # Side walls reuse front/back vertices - normals imperfect but geometry sealed
            faces.extend([front[aa],back[aa],front[bb], front[bb],back[aa],back[bb]])
            side_count+=2
    # Recompute vertex normals? keep the analytic smooth surface normals above.
    p=np.asarray(verts,np.float32);n=np.asarray(normals,np.float32);uv=np.asarray(uv,np.float32);idx=np.asarray(faces,np.uint32)
    # glTF model: two-sided PBR texture with alpha cutoff, compact single GLB file
    buffers=[];views=[]
    def addbin(name,blob,target=None):
        offset=sum(len(t) for t in buffers);offset=align(offset,4);current=sum(len(t) for t in buffers)
        if offset>current:buffers.append(b'\0'*(offset-current))
        buffers.append(blob);view={'buffer':0,'byteOffset':offset,'byteLength':len(blob)}
        if target:view['target']=target
        views.append(view);return len(views)-1
    vpos=addbin('pos',p.tobytes(),34962);vnorm=addbin('normals',n.tobytes(),34962);vuv=addbin('uvs',uv.tobytes(),34962);vix=addbin('idx',idx.tobytes(),34963);vtex=addbin('webp',texture)
    acc=[{'bufferView':vpos,'componentType':5126,'count':len(p),'type':'VEC3','min':p.min(axis=0).tolist(),'max':p.max(axis=0).tolist()},
         {'bufferView':vnorm,'componentType':5126,'count':len(n),'type':'VEC3'},
         {'bufferView':vuv,'componentType':5126,'count':len(uv),'type':'VEC2'},
         {'bufferView':vix,'componentType':5125,'count':len(idx),'type':'SCALAR'}]
    model={'asset':{'version':'2.0','generator':'PRMR R07 single-view photo-sculpture — approximate depth, mirrored reverse'},
      'extensionsUsed':['EXT_texture_webp'],
      'scene':0,'scenes':[{'nodes':[0]}],
      'nodes':[{'mesh':0,'name':'reconstruction_artistique_non_anatomique_'+id}],
      'meshes':[{'name':id+'_photo_inflated_shell','primitives':[{'attributes':{'POSITION':0,'NORMAL':1,'TEXCOORD_0':2},'indices':3,'material':0,'mode':4}]}],
      'materials':[{'name':'photo_couleur_source_'+id,'doubleSided':True,'pbrMetallicRoughness':{'baseColorTexture':{'index':0},'metallicFactor':0,'roughnessFactor':.88},'alphaMode':'MASK','alphaCutoff':.13}],
      'textures':[{'extensions':{'EXT_texture_webp':{'source':0}}}],
      'images':[{'bufferView':vtex,'mimeType':'image/webp'}],
      'accessors':acc,'bufferViews':views,'buffers':[{'byteLength':sum(len(b) for b in buffers)}]}
    js=json.dumps(model,separators=(',',':')).encode('utf-8');js+=b' '*(align(len(js),4)-len(js))
    binary=b''.join(buffers);binary+=b'\x00'*(align(len(binary),4)-len(binary))
    total=12+8+len(js)+8+len(binary)
    out=b'glTF'+struct.pack('<II',2,total)+struct.pack('<I4s',len(js),b'JSON')+js+struct.pack('<I4s',len(binary),b'BIN\0')+binary
    outpath=OUT/'animals-3d'/f'{id}.glb';outpath.write_bytes(out)
    return {'species_id':id,'asset':f'assets/animals-3d/{id}.glb','poster':f'assets/animals-photo/{id}.webp','size_bytes':outpath.stat().st_size,'poster_bytes':webp.stat().st_size,'sha256':hashlib.sha256(out).hexdigest(),'source_png':filename,'vertices':len(verts),'triangles':len(idx)//3,'texture_size':[512,384],'format':'glb','reconstruction':'2.5D photo-relief (real textured 3D surface, mirrored reverse, non-anatomic)','license':'Original generated PRMR asset','validation':'visual only, non-quantitative'}
result=[]
for id,filename in FILES.items():
 t=time.time();r=build(id,filename);print(id,'GLB',r['size_bytes'],'tex',r['poster_bytes'],'verts',r['vertices'],'tris',r['triangles'],'sec',round(time.time()-t,2));result.append(r)
manifest={'version':'r07-photo-relief-v1','created_utc':'2026-11-17','source':'six generated PNG cutouts from PRMR conversation','type':'real 3D meshes textured with user-approved generated visual skin; artistically reconstructed from a single image','not_anatomical':True,'true_360_photo_model':False,'warning':'Model reverse and depth are estimated; mesh is not a multi-view anatomical reconstruction. Front/side visual fidelity is higher than the reverse. No medical measurement or prediction from geometry.','assets':result}
(OUT/'animals-3d'/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
